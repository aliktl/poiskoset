from django.shortcuts import render
from rest_framework.generics import get_object_or_404
from .serializers import UserSerializer, BookSerializer
from django.contrib.auth.models import User
from .models import Book

from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.exceptions import AuthenticationFailed
import jwt, datetime


class RegisterView(APIView):
    def post(self, request):
        serializer = UserSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response(serializer.data)


class LoginView(APIView):
    def post(self, request):
        email = request.data['email']
        password = request.data['password']
        user = User.objects.filter(email=email).first()
        if user is None:
            raise AuthenticationFailed('User not found')
        if not user.check_password(password):
            raise AuthenticationFailed('Incorrect password')
        payload = {
            'id': user.id,
            'exp': datetime.datetime.utcnow() + datetime.timedelta(minutes=60),
            'iat': datetime.datetime.utcnow()
        }
        token = jwt.encode(payload, 'secret', algorithm='HS256')
        response = Response()

        response.set_cookie(key='jwt', value=token, httponly=True)
        response.data = {
            'jwt': token
        }
        return response


class UserView(APIView):
    def get(self, request):
        token = request.COOKIES.get('jwt')
        if not token:
            raise AuthenticationFailed('Unauthenticated!')
        try:
            payload = jwt.decode(token, 'secret', algorithms=['HS256'])
        except jwt.ExpiredSignatureError:
            raise AuthenticationFailed('Unauthenticated!')
        user = User.objects.filter(id=payload['id']).first()
        serializer = UserSerializer(user)
        return Response(serializer.data)


class LogoutView(APIView):
    def post(self, request):
        response = Response()
        response.delete_cookie('jwt')
        response.data = {
            'message': 'success'
        }
        return response


# views for book and crud
from rest_framework.decorators import api_view

from rest_framework import status
from rest_framework import serializers


# create
@api_view(['POST'])
def add_book(request):
    book = BookSerializer(data=request.data)
    if Book.objects.filter(**request.data).exists():
        raise serializers.ValidationError('This data already exists')
    if book.is_valid():
        book.save()
        return Response(book.data)
    else:
        return Response(status=status.HTTP_404_NOT_FOUND)


# view
@api_view(['GET'])
def view_items(request, pk):
    item = Book.objects.get(pk=pk)
    if item:
        data2 = BookSerializer(item)
        return Response(data2.data)
    else:
        return Response(status=status.HTTP_404_NOT_FOUND)


# update
@api_view(['POST'])
def update_items(request, pk):
    item = Book.objects.get(pk=pk)
    data = BookSerializer(instance=item, data=request.data)
    if data.is_valid():
        data.save()
        return Response(data.data)
    else:
        return Response(status=status.HTTP_404_NOT_FOUND)


# delete
@api_view(['DELETE'])
def delete_items(request, pk):
    item = get_object_or_404(Book, pk=pk)
    item.delete()
    return Response(status=status.HTTP_202_ACCEPTED)


# view holder
@api_view(['GET'])
def view_holder(request, pk):
    items = Book.objects.filter(holder=pk)
    if items:
        data2 = BookSerializer(items, many=True)
        return Response(data2.data)
    else:
        return Response(status=status.HTTP_404_NOT_FOUND)
