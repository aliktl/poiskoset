from django.db import models
from django.contrib.auth.models import User

# Create your models here.

"Book - это наша модель для объектов книг"


class Book(models.Model):
    name = models.CharField(max_length=255)
    group = models.CharField(max_length=255)
    pages = models.CharField(max_length=255)
    author = models.CharField(max_length=255)
    cover = models.BooleanField()
    holder = models.ForeignKey(User, on_delete=models.CASCADE, default=None)


"Все категории для книги включая название жанр и так далее"
