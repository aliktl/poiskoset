from django.contrib import admin

from .models import Book

# Register your models here.
"Здесь реализованы функции поиска и сортировки вместе с пагинацией"


class BookAdmin(admin.ModelAdmin):
    list_display = ('id', 'name', 'group', 'pages', 'author', 'cover', 'holder')
    search_fields = ['name']
    list_filter = ('group', 'pages', 'author', 'cover')
    list_per_page = 50


admin.site.register(Book, BookAdmin)
