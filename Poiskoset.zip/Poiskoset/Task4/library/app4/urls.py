from .views import RegisterView, LoginView, UserView, LogoutView
from django.urls import path, include
from . import views
from rest_framework_swagger.views import get_swagger_view


schema_view = get_swagger_view(title='My Project Swagger',)

urlpatterns = [
    # путь для swagger
    path('swagger', schema_view,),

    # путь для регистрации и авторизации пользователя
    path('register', RegisterView.as_view()),
    path('login', LoginView.as_view()),
    path('user', UserView.as_view()),
    path('logout', LogoutView.as_view()),

    # путь для CRUD
    path('create/', views.add_book),
    path('view/<int:pk>/', views.view_items),
    path('update/<int:pk>/', views.update_items),
    path('delete/<int:pk>/', views.delete_items),

    # путь для всех книг определенного пользователя
    path('view_holder/<int:pk>/', views.view_holder),
]