from django.core.management.base import BaseCommand
from django.utils import timezone
from ...views import callDB


class Command(BaseCommand):
    def handle(self, *args, **kwargs):
        callDB(1, First='One')
