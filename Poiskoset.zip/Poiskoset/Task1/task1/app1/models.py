from django.db import models


# Create your models here.
class Sample1(models.Model):
    sample = models.CharField(max_length=10)
