from django.shortcuts import render

# Create your views here.
from .models import Sample1
import time


def decor(func):
    def inner(*args, **kwargs):
        begin = time.time()
        func(*args, **kwargs)
        end = time.time()
        print('Start time: {}'.format(begin))
        print('End time: {}'.format(end))
        print('Total time in seconds: {}'.format(end - begin))
    return inner



@decor
def callDB(*args, **kwargs):
    for i in args:
        print(i)
    for i, j in kwargs.items():
        print(i, j)
    objects = Sample1.objects.all()
    for i in objects:
        print(i.sample)
