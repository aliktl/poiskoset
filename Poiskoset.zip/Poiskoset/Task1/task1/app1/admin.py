from django.contrib import admin

# Register your models here.
from .models import Sample1


class Sample1Admin(admin.ModelAdmin):
    list_display = ('sample',)
    # actions = [callDB]


admin.site.register(Sample1, Sample1Admin)
