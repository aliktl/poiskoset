array = [[1], [8, 7, 1, 0], [76, [98, 6]], 38]

cnt = 0
maximum = float('-inf')


def recursion(lst):
    global cnt
    global maximum
    if not lst:
        return 0
    count = 0
    for el in lst:
        if not isinstance(el, list):
            count += el
            cnt += 1
            maximum = max(maximum, el)
        else:
            count += recursion(el)
    return count


total = recursion(array)
# print(total, cnt, maximum)

print("Максимум: {}".format(maximum))
print('Среднее: {}'.format(total / cnt))
