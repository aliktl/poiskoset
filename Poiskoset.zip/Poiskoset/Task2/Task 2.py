def clockAngel(hour, minute):
    ans = abs((hour * 30 + minute * 0.5) - (minute * 6))
    print(min(360 - ans, ans))
    return min(360 - ans, ans)


clockAngel(9, 25)
